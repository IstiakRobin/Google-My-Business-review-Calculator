document.getElementById('calculate-btn').addEventListener('click', calculateScore);
document.getElementById('rating').addEventListener('input', updateRatingValue);
document.getElementById('desired-rating').addEventListener('input', updateDesiredRatingValue);

function calculateScore() {
  var reviews = parseInt(document.getElementById('reviews').value);
  var rating = parseFloat(document.getElementById('rating').value);
  var desiredRating = parseFloat(document.getElementById('desired-rating').value);

  if (isNaN(reviews) || isNaN(rating) || isNaN(desiredRating) || rating < 0 || rating > 5 || desiredRating < 0 || desiredRating > 5) {
    document.getElementById('result').innerHTML = 'Please enter valid values.';
    return;
  }

  var currentScore = reviews * rating;
  var desiredScore = reviews * desiredRating;

  if (desiredRating === 5) {
    if (rating === 5) {
      document.getElementById('result').innerHTML = 'You already have the desired rating.';
    } else {
      var targetReviews = Math.ceil((desiredScore - currentScore) / (5 - rating));
      document.getElementById('result').innerHTML = 'To achieve an average rating of 5.00, you will need approximately ' + targetReviews + ' additional 5-star reviews.';
    }
  } else if (desiredRating <= rating) {
    document.getElementById('result').innerHTML = 'You already have the desired rating.';
  } else {
    var targetReviews = Math.ceil((desiredScore - currentScore) / (5 - desiredRating));
    document.getElementById('result').innerHTML = 'To achieve an average rating of ' + desiredRating.toFixed(2) + ', you will need approximately ' + targetReviews + ' additional 5-star reviews.';
  }
}

function updateRatingValue() {
  var ratingValue = document.getElementById('rating').value;
  document.getElementById('rating-value').innerHTML = ratingValue;
}

function updateDesiredRatingValue() {
  var desiredRatingValue = document.getElementById('desired-rating').value;
  if (desiredRatingValue === '5') {
    document.getElementById('desired-rating-value').innerHTML = '5.00';
  } else {
    document.getElementById('desired-rating-value').innerHTML = desiredRatingValue;
  }
}
